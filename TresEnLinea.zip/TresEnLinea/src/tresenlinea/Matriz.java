/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tresenlinea;

/**
 *
 * @author ricar
 */
public class Matriz {
    String[][] matriz;
    int filas;
    int columnas;
    
    public Matriz(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
        this.matriz = new String[filas][columnas];
    }
    
    public void agregarEje(int i, int j, String dato) {
        matriz[i][j] = dato;
    }
    
    public boolean lleno() {
        int contador = 0;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if(matriz[i][j] != " ") {
                    ++contador;
                }
            }
        }
        if(contador == 9) {
            return true;
        }
        return false;
    }
    
    public void llenar() {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                agregarEje(i,j," ");
            }
        }
    }
    
    public boolean ganarFilas() {
        for (int i = 0; i < filas; i++) {
            int contador = 0;
            String temp = matriz[i][0];
            for (int j = 0; j < columnas; j++) {
                if(matriz[i][j] == temp && temp != " ") {
                    ++contador;
                }
            }
            if(contador == 3) {
                return true;
            }
        }
        return false;
    }
    
    public boolean ganarColumnas() {
        int columna = 0;
        for (int i = 0; i < filas; i++) {
            int contador = 0;
            String temp = matriz[0][columna];
            for (int j = 0; j < filas; j++) {
                if(matriz[j][columna] == temp && temp != " ") {
                    ++contador;
                }
            }
            if(contador == 3) {
                return true;
            } else {
                ++columna;
            }
        }
        return false;
    }
    
    public boolean ganarDiagonal() {
        String temp1 = matriz[0][0];
        String temp2 = matriz[0][2];
        if(matriz[1][1] == temp1 && matriz[2][2] == temp1 && temp1 != " ") {
            return true;
        } else if(matriz[1][1] == temp2 && matriz[2][0] == temp2 && temp2 != " ") {
            return true;
        }
        return false;
    }
    
    public boolean ganar() {
//        if(ganarFilas()) {
//            return true;
//        } else if(ganarColumnas()) {
//            return true;
//        } else if(ganarDiagonal()) {
//            return true;
//        }
//        return false;
          return ganarFilas() || ganarColumnas() || ganarDiagonal();
    }
}
